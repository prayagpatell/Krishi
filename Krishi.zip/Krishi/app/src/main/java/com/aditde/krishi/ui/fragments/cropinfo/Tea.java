package com.aditde.krishi.ui.fragments.cropinfo;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.aditde.krishi.R;

public class Tea extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tea);
    }
}